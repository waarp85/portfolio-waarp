# -*- coding: utf-8 -*-
# Scene Colorizer - free Cinema 4D plugin by Andrea Marcias - www.andreamarcias.com
import c4d
from c4d import gui, plugins, bitmaps
import random
import colorsys
import os

# Plugin Configuration
PLUGIN_ID = 1074094  # registered on plugincafe (Maxon), 13/11/2026
PLUGIN_NAME = "Scene Colorizer"
PLUGIN_VERSION = "1.0"   # first public release (13/11/2026)

# UI Element IDs
GRP_MAIN = 1000
GRP_OPTIONS = 1001
TXT_MODE = 1002
CMB_MODE = 1003
CHK_CHILDREN = 1004
CHK_ICONS = 1005
BTN_APPLY = 1006
BTN_RESET = 1008
TXT_BY = 1009
CMB_BY = 1010
TXT_HINT = 1011
GRP_FORM = 1012

# Color Mode Constants
MODE_PASTEL = 0
MODE_VIBRANT = 1
MODE_DARK = 2
MODE_LIGHT = 3

# "Colour by" constants
BY_OBJECT = 0   # every object gets its own colour
BY_GROUP = 1    # children get a shade of their top parent's colour

# (saturation range, value range) per palette
PALETTES = {
    MODE_PASTEL: ((0.35, 0.60), (0.95, 0.95)),
    MODE_VIBRANT: ((0.80, 1.00), (0.80, 1.00)),
    MODE_DARK: ((0.50, 0.80), (0.10, 0.30)),
    MODE_LIGHT: ((0.10, 0.30), (0.90, 1.00)),
}
GOLDEN = 0.61803398875   # golden-ratio step: neighbouring objects never get similar hues
GROUP_HUE_JITTER = 0.035  # how far a child's hue can drift from its group's hue

# Scene-wide objects that are left alone: a coloured Sky would tint the whole viewport background
SKIP_TYPES = (c4d.Osky, c4d.Obackground, c4d.Oenvironment, c4d.Oforeground)

# Saved settings (remembered between sessions)
SET_MODE, SET_BY, SET_CHILDREN, SET_ICONS = 1, 2, 3, 4


def status(text):
    """Status bar text. Newer Cinema 4D versions moved the function to c4d.gui."""
    fn = getattr(gui, "StatusSetText", None) or c4d.StatusSetText
    fn(text)


class ColorizerHelper:
    """Colour generation and scene walking (no UI in here)."""

    def __init__(self, mode):
        self.sat, self.val = PALETTES.get(mode, ((0.5, 0.5), (0.5, 0.5)))
        self.hue = random.random()

    def next_hue(self):
        """A new hue, well apart from the previous one."""
        self.hue = (self.hue + GOLDEN) % 1.0
        return self.hue

    def color(self, hue):
        s = random.uniform(*self.sat)
        v = random.uniform(*self.val)
        return c4d.Vector(*colorsys.hsv_to_rgb(hue % 1.0, s, v))

    def shade(self, hue):
        """A variation of a group's colour: same family, slightly different."""
        return self.color(hue + random.uniform(-GROUP_HUE_JITTER, GROUP_HUE_JITTER))

    @staticmethod
    def apply_color(obj, color, colorize_icon):
        obj[c4d.ID_BASEOBJECT_USECOLOR] = 2  # always use the display colour
        obj[c4d.ID_BASEOBJECT_COLOR] = color
        if colorize_icon:
            obj[c4d.ID_BASELIST_ICON_COLORIZE_MODE] = 1
            obj[c4d.ID_BASELIST_ICON_COLOR] = color

    @staticmethod
    def reset_color(obj):
        obj[c4d.ID_BASEOBJECT_USECOLOR] = 0
        obj[c4d.ID_BASELIST_ICON_COLORIZE_MODE] = 0


def get_targets(doc):
    """Selected objects, or every top-level object if nothing is selected."""
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_SELECTIONORDER)
    if sel:
        return sel
    out = []
    obj = doc.GetFirstObject()
    while obj:
        out.append(obj)
        obj = obj.GetNext()
    return out


def walk(root):
    """root and all its descendants, without recursion (safe on very deep hierarchies)."""
    stack = [root]
    while stack:
        obj = stack.pop()
        yield obj
        kids = obj.GetChildren()
        kids.reverse()
        stack.extend(kids)


def colorize(doc, mode, by, children, icons):
    """Returns the number of objects coloured."""
    targets = get_targets(doc)
    if not targets:
        return 0
    helper = ColorizerHelper(mode)
    done = set()
    count = 0
    doc.StartUndo()
    for root in targets:
        hue = helper.next_hue()
        for obj in (walk(root) if children else (root,)):
            key = obj.GetGUID()
            if key in done:      # e.g. a parent and its child both selected
                continue
            done.add(key)
            if obj.GetType() in SKIP_TYPES:
                continue
            if obj is root or obj == root:
                col = helper.color(hue)
            elif by == BY_GROUP:
                col = helper.shade(hue)
            else:
                col = helper.color(helper.next_hue())
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, obj)
            ColorizerHelper.apply_color(obj, col, icons)
            count += 1
    doc.EndUndo()
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)
    return count


def remove_colors(doc, children):
    """Returns the number of objects reset."""
    targets = get_targets(doc)
    if not targets:
        return 0
    done = set()
    count = 0
    doc.StartUndo()
    for root in targets:
        for obj in (walk(root) if children else (root,)):
            key = obj.GetGUID()
            if key in done:
                continue
            done.add(key)
            if obj.GetType() in SKIP_TYPES:
                continue
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, obj)
            ColorizerHelper.reset_color(obj)
            count += 1
    doc.EndUndo()
    c4d.EventAdd(c4d.EVENT_FORCEREDRAW)
    return count


class ColorizerDialog(gui.GeDialog):
    """Main dialog interface for Scene Colorizer"""

    def CreateLayout(self):
        self.SetTitle(PLUGIN_NAME)

        if self.GroupBegin(GRP_MAIN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "", 0):
            self.GroupBorderSpace(10, 10, 10, 10)

            if self.GroupBegin(GRP_FORM, c4d.BFH_SCALEFIT, 2, 0, "", 0):
                self.AddStaticText(TXT_MODE, c4d.BFH_LEFT, 0, 0, "Palette", 0)
                self.AddComboBox(CMB_MODE, c4d.BFH_SCALEFIT)
                self.AddChild(CMB_MODE, MODE_PASTEL, "Pastel (Soft)")
                self.AddChild(CMB_MODE, MODE_VIBRANT, "Vibrant (Saturated)")
                self.AddChild(CMB_MODE, MODE_DARK, "Dark (Moody)")
                self.AddChild(CMB_MODE, MODE_LIGHT, "Light (Subtle)")

                self.AddStaticText(TXT_BY, c4d.BFH_LEFT, 0, 0, "Colour by", 0)
                self.AddComboBox(CMB_BY, c4d.BFH_SCALEFIT)
                self.AddChild(CMB_BY, BY_OBJECT, "Object (each one different)")
                self.AddChild(CMB_BY, BY_GROUP, "Group (children match their parent)")
            self.GroupEnd()

            self.AddSeparatorH(c4d.BFH_SCALEFIT)

            self.AddCheckbox(CHK_CHILDREN, c4d.BFH_LEFT, 0, 0, "Include children")
            self.AddCheckbox(CHK_ICONS, c4d.BFH_LEFT, 0, 0, "Colour the Object Manager icons")

            self.AddSeparatorH(c4d.BFH_SCALEFIT)

            if self.GroupBegin(GRP_OPTIONS, c4d.BFH_SCALEFIT, 2, 0, "", 0):
                self.AddButton(BTN_APPLY, c4d.BFH_SCALEFIT, 0, 30, "Colorize")
                self.AddButton(BTN_RESET, c4d.BFH_SCALEFIT, 0, 30, "Remove Colors")
            self.GroupEnd()

            self.AddStaticText(TXT_HINT, c4d.BFH_CENTER, 0, 0,
                               "Selected objects, or the whole scene if nothing is selected.", 0)

        self.GroupEnd()
        return True

    def InitValues(self):
        bc = plugins.GetWorldPluginData(PLUGIN_ID) or c4d.BaseContainer()
        self.SetInt32(CMB_MODE, bc.GetInt32(SET_MODE, MODE_PASTEL))
        self.SetInt32(CMB_BY, bc.GetInt32(SET_BY, BY_OBJECT))
        self.SetBool(CHK_CHILDREN, bc.GetBool(SET_CHILDREN, True))
        self.SetBool(CHK_ICONS, bc.GetBool(SET_ICONS, True))
        self.update_ui()
        return True

    def update_ui(self):
        # "Group" only makes sense when children are included
        self.Enable(CMB_BY, self.GetBool(CHK_CHILDREN))

    def save_settings(self):
        bc = c4d.BaseContainer()
        bc.SetInt32(SET_MODE, self.GetInt32(CMB_MODE))
        bc.SetInt32(SET_BY, self.GetInt32(CMB_BY))
        bc.SetBool(SET_CHILDREN, self.GetBool(CHK_CHILDREN))
        bc.SetBool(SET_ICONS, self.GetBool(CHK_ICONS))
        plugins.SetWorldPluginData(PLUGIN_ID, bc, False)

    def Command(self, id, msg):
        if id == BTN_APPLY:
            self.on_apply()
        elif id == BTN_RESET:
            self.on_reset()
        elif id in (CMB_MODE, CMB_BY, CHK_CHILDREN, CHK_ICONS):
            self.update_ui()
            self.save_settings()
        return True

    def on_apply(self):
        doc = c4d.documents.GetActiveDocument()
        if not doc:
            return
        n = colorize(doc, self.GetInt32(CMB_MODE), self.GetInt32(CMB_BY),
                     self.GetBool(CHK_CHILDREN), self.GetBool(CHK_ICONS))
        status("Colorized %d objects." % n if n else "Scene is empty.")

    def on_reset(self):
        doc = c4d.documents.GetActiveDocument()
        if not doc:
            return
        n = remove_colors(doc, self.GetBool(CHK_CHILDREN))
        status("Removed colours from %d objects." % n if n else "Scene is empty.")


class ColorizerCommand(plugins.CommandData):
    """Command plugin registration class"""

    dialog = None

    def Execute(self, doc):
        if self.dialog is None:
            self.dialog = ColorizerDialog()
        return self.dialog.Open(dlgtype=c4d.DLG_TYPE_ASYNC,
                                pluginid=PLUGIN_ID,
                                defaultw=320,
                                defaulth=200)

    def RestoreLayout(self, sec_ref):
        if self.dialog is None:
            self.dialog = ColorizerDialog()
        return self.dialog.Restore(PLUGIN_ID, secret=sec_ref)


def RegisterMyPlugin():
    icon = bitmaps.BaseBitmap()
    icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
    if icon.InitWith(icon_path)[0] != c4d.IMAGERESULT_OK:
        icon = None

    plugins.RegisterCommandPlugin(
        PLUGIN_ID,
        PLUGIN_NAME,
        0,
        icon,
        "Give every object its own colour, in the viewport and in the Object Manager",
        ColorizerCommand()
    )


if __name__ == "__main__":
    RegisterMyPlugin()
