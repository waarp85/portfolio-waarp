SCENE COLORIZER  -  v1.0
Free Cinema 4D plugin by Andrea Marcias  -  www.andreamarcias.com

Gives every object in your scene its own colour in one click, so you can read a
busy scene at a glance. The colours are saved in the scene: they show in the
viewport and, if you want, on the object icons in the Object Manager.

- Four palettes: Pastel, Vibrant, Dark, Light
- Colour by Object (every object different, neighbours never look alike)
  or by Group (children get a shade of their parent's colour)
- Works on the selected objects, or on the whole scene if nothing is selected
- Optional: include children, colour the Object Manager icons
- Remove Colors takes them off again. Everything can be undone (Ctrl+Z / Cmd+Z).
- Your settings are remembered between sessions.
- Sky, Background, Environment and Foreground objects are left alone.

Note: Colorize replaces any display colour you set by hand on those objects,
and Remove Colors switches display colour and icon colour off.

--------------------------------------------------
COMPATIBILITY
--------------------------------------------------
Made for Cinema 4D 2025 - 2027 (Windows and macOS).
It should also work on R23 - 2024. It does not run on R22 or older.

--------------------------------------------------
INSTALLATION
--------------------------------------------------
1) In Cinema 4D: Edit > Preferences, then click "Open Preferences Folder..."
   at the bottom left.
2) Open the "plugins" folder (create it if it doesn't exist).
3) Copy the "SceneColorizer" folder (the one containing this file) into "plugins".
4) Restart Cinema 4D.
5) Open it from the Extensions menu > Scene Colorizer.

--------------------------------------------------
LICENSE
--------------------------------------------------
Free for personal and commercial work. Please don't sell it or re-upload it:
share the official page instead: https://www.andreamarcias.com/scene-colorizer.html
Provided "as is", without warranty of any kind.
Cinema 4D is a trademark of Maxon Computer GmbH. Not affiliated with Maxon.
